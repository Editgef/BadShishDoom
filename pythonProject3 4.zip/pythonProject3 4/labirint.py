from copy import deepcopy
from random import choice


def vector(num_input, width, height):
    y, x = num_input[0], num_input[1]
    variants = []
    for i in [[y - 2, x], [y, x + 2], [y + 2, x], [y, x - 2]]:
        if height > i[0] >= 0 and width > i[1] >= 0:
            variants.append([i[0], i[1]])
    return variants

def finder(num_one, num_input):
    for i in num_one:
        for j in i:
            if j == num_input:
                return i


width, height = 23, 15
num = [[0 if x % 2 == 0 else 1 for x in range(width)] if y % 2 == 0 else [1 for i in range(width)] for y in
       range(height)]

num_one = [[[y, x]] for y in range(0, height, 2) for x in range(0, width, 2)]

num_one_const = deepcopy(num_one)

while len(num_one) != 1:
    group = choice(num_one)
    n = choice(group)
    where = choice(vector(n, width, height))
    if where not in group:
        groupWhere = finder(num_one, where)
        group.extend(groupWhere)
        num[(n[0] + where[0]) // 2][(n[1] + where[1]) // 2] = 0
        num_one.remove(groupWhere)
for i in num:
    print(i)